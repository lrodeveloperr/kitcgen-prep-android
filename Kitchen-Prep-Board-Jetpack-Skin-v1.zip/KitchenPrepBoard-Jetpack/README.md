# Kitchen Prep Board — Jetpack Compose skin

Generated from the authoritative backend spec SHA-256 `431414417d83201263951f0f3ed5854d38da88c7ec1b96c8e3d42168e556083b` and the current GoodUse UI control plane.

## What this package is
This is the **presentation skin + backend presentation port**, not a replacement for the locked backend engine. The supplied JSON backend is an implementation specification rather than executable Kotlin, so the app includes `KitchenBackendPort` and a deterministic `PreviewKitchenBackend` for previews. Bind the production Room/scheduling/timer/billing implementation to the same port without changing the screen/action contract.

## Locked UI direction
- GoodUse shell: `GOODUSE_NATIVE_SHELL_V1` 1.3.0 semantics.
- Task-first, focused-workflow shell.
- No runtime photos, illustrations, thumbnails or image placeholders.
- Same shared palette, spacing, type hierarchy and screen/action structure as the SwiftUI package.
- Compact layout is stacked. At 840dp+ the run board reflows to Now / Next / Waiting lanes.
- Android targetSdk remains 36 per backend; compileSdk uses shell baseline 37.
- The bottom ad region is **collapsed until actually loaded**, because the app backend explicitly says `reserveLayoutSpaceOnlyWhenAdLoaded=true`.
- Google Play/AdMob/UMP production adapters are not fabricated in this skin package.

## Build
Open the root folder in Android Studio or use a compatible Gradle 9.3.1 / JDK 17 environment. A wrapper is not fabricated here because wrapper binaries were not supplied by the connected shell repository interface.

## Source authority
`contract/Kitchen-Prep-Board-Android-Backend-v1.1.0.json` is byte-for-byte the supplied backend source.
`contract/KitchenPrepBoard-UI-Contract-v1.0.0.json` is the synchronized Android/iOS presentation contract.
