package studio.gooduse.kitchenprep

import androidx.compose.runtime.*

/**
 * Presentation port only. The authoritative v1.1.0 backend contract is bundled in /contract.
 * Production integration should adapt the real Room/scheduling/timer/billing implementation to
 * this port. This preview adapter intentionally does not pretend to implement that backend.
 */
interface KitchenBackendPort {
    val state: State<KitchenUiState>
    fun dispatch(action:String, payload:String?=null)
}

class PreviewKitchenBackend(initialSharedText:String?=null): KitchenBackendPort {
    private val mutable = mutableStateOf(
        KitchenUiState(
            backendState = if (initialSharedText.isNullOrBlank()) BackendState.HOME else BackendState.QUICK_REVIEW,
            sourceText = initialSharedText.orEmpty()
        )
    )
    override val state: State<KitchenUiState> get() = mutable

    override fun dispatch(action:String,payload:String?) {
        val s=mutable.value
        mutable.value = when(action) {
            "ONBOARD_NEXT" -> if (s.onboardingPage < 1) s.copy(onboardingPage=s.onboardingPage+1)
                               else s.copy(onboardingComplete=true)
            "NEW_BOARD" -> s.copy(backendState=BackendState.CREATE_BOARD)
            "INPUT_CAPTURED" -> s.copy(backendState=BackendState.QUICK_REVIEW, sourceText=payload ?: s.sourceText)
            "REVIEW_CONFIRMED" -> s.copy(backendState=BackendState.SELECT_MODE)
            "MODE_HOME" -> s.copy(backendState=BackendState.MODE_SPECIFIC_SETUP,mode=BoardMode.HOME)
            "MODE_STATION" -> s.copy(backendState=BackendState.MODE_SPECIFIC_SETUP,mode=BoardMode.STATION)
            "MODE_CONFIRMED" -> s.copy(backendState=if(s.mode==BoardMode.STATION) BackendState.PREP_GAP else BackendState.TIMING_OBJECTIVE)
            "PREP_GAP_CONFIRMED" -> s.copy(backendState=BackendState.TIMING_OBJECTIVE)
            "TIMING_COOK_NOW" -> s.copy(backendState=BackendState.READY_OVERVIEW,timing=TimingMode.COOK_NOW)
            "TIMING_SERVE_AT" -> s.copy(backendState=BackendState.READY_OVERVIEW,timing=TimingMode.SERVE_AT)
            "TIMING_READY_BY" -> s.copy(backendState=BackendState.READY_OVERVIEW,timing=TimingMode.READY_BY)
            "BOARD_STARTED" -> s.copy(backendState=BackendState.RUN_BOARD)
            "PAUSE" -> s.copy(backendState=BackendState.PAUSED_BOARD,paused=true)
            "RESUME" -> s.copy(backendState=BackendState.RUN_BOARD,paused=false)
            "OPEN_FINISH" -> s.copy(backendState=BackendState.FINISH)
            "FINISH_ANYWAY" -> s.copy(backendState=BackendState.REUSE_OR_HOME)
            "RETURN_HOME" -> s.copy(backendState=BackendState.HOME)
            "SETTINGS" -> s.copy(settingsReturn=s.backendState,backendState=BackendState.SETTINGS)
            "CLOSE_SETTINGS" -> s.copy(backendState=s.settingsReturn)
            "SAFETY_ACK" -> s.copy(safetyDisclosureNeeded=false)
            else -> s
        }
    }
}
