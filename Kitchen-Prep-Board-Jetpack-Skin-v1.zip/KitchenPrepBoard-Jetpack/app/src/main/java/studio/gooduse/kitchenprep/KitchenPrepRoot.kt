package studio.gooduse.kitchenprep

import androidx.compose.runtime.*
import androidx.compose.ui.tooling.preview.Preview
import studio.gooduse.shell.*

@Composable
fun KitchenPrepRoot(
    initialSharedText:String?=null,
    backend:KitchenBackendPort = remember { PreviewKitchenBackend(initialSharedText) }
) {
    val state by backend.state
    GoodUseFrame(
        bottomRail = if (state.adLoaded && state.onboardingComplete) {
            { LoadedAdRailPlaceholder() }
        } else null
    ) {
        if (!state.onboardingComplete) {
            OnboardingScreen(state.onboardingPage) { backend.dispatch("ONBOARD_NEXT") }
        } else {
            KitchenScreen(state, backend::dispatch)
        }
    }
}

@Composable
private fun LoadedAdRailPlaceholder() {
    // Development geometry only. Production injects the loaded adaptive AdMob view here.
    // The backend contract requires the rail to stay collapsed until the ad is loaded.
}

@Preview(widthDp=412,heightDp=915,showBackground=true)
@Composable private fun CompactPreview() {
    KitchenPrepRoot(backend=PreviewKitchenBackend().also { it.dispatch("ONBOARD_NEXT"); it.dispatch("ONBOARD_NEXT"); it.dispatch("NEW_BOARD"); it.dispatch("INPUT_CAPTURED"); it.dispatch("REVIEW_CONFIRMED"); it.dispatch("MODE_STATION"); it.dispatch("MODE_CONFIRMED"); it.dispatch("PREP_GAP_CONFIRMED"); it.dispatch("TIMING_COOK_NOW"); it.dispatch("BOARD_STARTED") })
}

@Preview(widthDp=1024,heightDp=768,showBackground=true)
@Composable private fun WidePreview() {
    KitchenPrepRoot(backend=PreviewKitchenBackend().also { it.dispatch("ONBOARD_NEXT"); it.dispatch("ONBOARD_NEXT"); it.dispatch("NEW_BOARD"); it.dispatch("INPUT_CAPTURED"); it.dispatch("REVIEW_CONFIRMED"); it.dispatch("MODE_STATION"); it.dispatch("MODE_CONFIRMED"); it.dispatch("PREP_GAP_CONFIRMED"); it.dispatch("TIMING_COOK_NOW"); it.dispatch("BOARD_STARTED") })
}
