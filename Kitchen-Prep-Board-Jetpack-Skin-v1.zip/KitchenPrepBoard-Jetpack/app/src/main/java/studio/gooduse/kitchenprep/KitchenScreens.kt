package studio.gooduse.kitchenprep

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import studio.gooduse.shell.*

@Composable
fun OnboardingScreen(page:Int, next:()->Unit) {
    Column(
        Modifier.fillMaxSize().padding(vertical=24.dp),
        verticalArrangement=Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement=Arrangement.spacedBy(16.dp)) {
            Text(if(page==0) "Kitchen Prep Board" else "A board in three moves", style=MaterialTheme.typography.headlineLarge)
            if(page==0) {
                Text("Prep without the scramble", style=MaterialTheme.typography.titleLarge)
                Text("See what to do now, what comes next, and what needs attention—without turning your station into restaurant software.")
                GUSection {
                    Text("Local-first. No account. Your boards stay on this device.", color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                Step(1,"Add or paste your tasks")
                Step(2,"Choose Home or Station mode")
                Step(3,"Choose Cook now, Serve at, or Ready by, then run the board")
            }
        }
        GUPrimary(if(page==0) "Continue" else "Start", next)
    }
}

@Composable private fun Step(n:Int,text:String) {
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        Surface(shape=RoundedCornerShape(999.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.12f)) {
            Text("$n",Modifier.padding(horizontal=12.dp,vertical=8.dp),fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.primary)
        }
        Text(text,style=MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun KitchenScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    when(s.backendState) {
        BackendState.HOME -> HomeScreen(s,dispatch)
        BackendState.CREATE_BOARD -> CreateScreen(s,dispatch)
        BackendState.QUICK_REVIEW -> ReviewScreen(s,dispatch)
        BackendState.SELECT_MODE -> ModeScreen(s,dispatch)
        BackendState.MODE_SPECIFIC_SETUP -> ModeSetupScreen(s,dispatch)
        BackendState.PREP_GAP -> PrepGapScreen(s,dispatch)
        BackendState.TIMING_OBJECTIVE -> TimingScreen(s,dispatch)
        BackendState.BUILD_EXECUTION_GRAPH -> BuildScreen()
        BackendState.READY_OVERVIEW -> ReadyScreen(s,dispatch)
        BackendState.RUN_BOARD -> RunBoardScreen(s,false,dispatch)
        BackendState.PAUSED_BOARD -> RunBoardScreen(s,true,dispatch)
        BackendState.FINISH -> FinishScreen(s,dispatch)
        BackendState.REUSE_OR_HOME -> ReuseScreen(s,dispatch)
        BackendState.SETTINGS -> SettingsScreen(s,dispatch)
    }
}

@Composable private fun SettingsButton(onClick:()->Unit) {
    IconButton(onClick=onClick,modifier=Modifier.size(48.dp)) {
        GoodUseVectorIcon("settings",Modifier.size(24.dp))
    }
}

@Composable
private fun HomeScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    LazyColumn(verticalArrangement=Arrangement.spacedBy(16.dp),contentPadding=PaddingValues(bottom=24.dp)) {
        item {
            GUHeader("Kitchen Prep Board","Tell the cook what to do now, what comes next, and how to get everything ready together.") {
                SettingsButton { dispatch("SETTINGS",null) }
            }
        }
        item {
            GUSection(emphasis=true) {
                Text("Start a board",style=MaterialTheme.typography.titleLarge)
                Text("Build from scratch or bring in task text. Nothing is uploaded.")
                GUPrimary("New prep board",{ dispatch("NEW_BOARD",null) },iconKey="plus")
            }
        }
        item {
            Text("Start from",style=MaterialTheme.typography.titleLarge)
            ActionRow("Paste task text","Split non-empty lines into editable tasks") { dispatch("NEW_BOARD",null) }
            ActionRow("Use a template","Create a fresh board from a saved template") { dispatch("NEW_BOARD",null) }
            ActionRow("Duplicate a board","Reuse structure without carrying live timers or task status") { dispatch("NEW_BOARD",null) }
            ActionRow("Reference URL","Stored as a reference only. The app does not fetch or scrape it.") { dispatch("NEW_BOARD",null) }
        }
        item {
            Text("Recent",style=MaterialTheme.typography.titleLarge)
            GUSection {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Dinner prep",fontWeight=FontWeight.SemiBold)
                        Text("Completed • 8 tasks",color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    GoodUseVectorIcon("history",Modifier.size(22.dp),MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun ActionRow(title:String,body:String,onClick:()->Unit) {
    Surface(onClick=onClick,color=Color.Transparent,modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.SemiBold); Text(body,color=MaterialTheme.colorScheme.onSurfaceVariant) }
            Text("›",fontSize=24.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CreateScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    var text by remember { mutableStateOf(s.sourceText.ifBlank { "Chop onions\nRoast vegetables\nMake herb dressing\nRest cooked chicken" }) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        GUHeader("Add prep tasks","Paste a list or type one task per line.")
        if(s.safetyDisclosureNeeded) {
            GUSection("Before your first board") {
                Text("This app is an organizational aid only. It does not guarantee food safety or doneness.")
                GUPrimary("I understand",{dispatch("SAFETY_ACK",null)})
            }
        }
        OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().heightIn(min=220.dp),label={Text("Tasks")},supportingText={Text("Original pasted/shared text is preserved.")})
        GUPrimary("Review tasks",{dispatch("INPUT_CAPTURED",text)})
    }
}

@Composable
private fun ReviewScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    val lines=s.sourceText.lines().filter{it.isNotBlank()}.ifEmpty { listOf("Chop onions","Roast vegetables","Make herb dressing") }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=24.dp)) {
        item { GUHeader("Quick review","Confirm wording, task kind and rough duration before the board is scheduled.") }
        itemsIndexed(lines) { i,line ->
            GUSection {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Text("${i+1}",Modifier.width(28.dp),color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Column(Modifier.weight(1f)) { Text(line,fontWeight=FontWeight.SemiBold); Text(if(i%2==0) "Prep • 8 min" else "Cook • 18 min",color=MaterialTheme.colorScheme.onSurfaceVariant) }
                    TextButton(onClick={}) { Text("Edit") }
                }
            }
        }
        item { GUPrimary("Choose mode",{dispatch("REVIEW_CONFIRMED",null)}) }
    }
}

@Composable
private fun ModeScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    Column(Modifier.padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        GUHeader("Where are you cooking?","This changes the setup flow, not your task text.")
        GUSection {
            Text("Home",style=MaterialTheme.typography.titleLarge)
            Text("A focused cooking board without station prep-gap tracking.")
            GUSecondary("Use Home mode",{dispatch("MODE_HOME",null)})
        }
        GUSection(emphasis=true) {
            Text("Station",style=MaterialTheme.typography.titleLarge)
            Text("Track target, on-hand and make quantities before running the station.")
            GUPrimary("Use Station mode",{dispatch("MODE_STATION",null)})
        }
    }
}

@Composable
private fun ModeSetupScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    Column(Modifier.padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        GUHeader(if(s.mode==BoardMode.STATION) "Station board" else "Home board","Your task text stays unchanged. You can override suggestions later.")
        GUSection {
            Text(if(s.mode==BoardMode.STATION) "Prep-gap tracking is available for this board." else "No station inventory or procurement layer is added.")
        }
        GUPrimary("Continue",{dispatch("MODE_CONFIRMED",null)})
    }
}

@Composable
private fun PrepGapScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=24.dp)) {
        item { GUHeader("Prep gap","Set what you need, what you have on hand, and what must be made.") }
        items(listOf("Herb dressing" to "Target 800 ml • On hand 250 ml • Make 550 ml","Roast vegetables" to "Target 12 portions • On hand 4 • Make 8")) { item ->
            GUSection {
                Text(item.first,fontWeight=FontWeight.SemiBold)
                Text(item.second)
                GUStatus("On-hand not verified","warning")
            }
        }
        item { Text("On-hand resets per shift. This is not an inventory ledger.",color=MaterialTheme.colorScheme.onSurfaceVariant) }
        item { GUPrimary("Set timing",{dispatch("PREP_GAP_CONFIRMED",null)}) }
    }
}

@Composable
private fun TimingScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    Column(Modifier.padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        GUHeader("Timing objective","The schedule is a suggestion. Your overrides always win.")
        Choice("Cook now","Start from the current time.") { dispatch("TIMING_COOK_NOW",null) }
        Choice("Serve at","Work backward from a serving time.") { dispatch("TIMING_SERVE_AT",null) }
        Choice("Ready by","Work backward from a ready deadline.") { dispatch("TIMING_READY_BY",null) }
    }
}

@Composable
private fun Choice(title:String,body:String,onClick:()->Unit) {
    Surface(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline),color=MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) { Text(title,fontWeight=FontWeight.SemiBold); Text(body,color=MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun BuildScreen() {
    Column(verticalArrangement=Arrangement.spacedBy(16.dp)) { GUHeader("Building suggested schedule"); LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Checking dependencies, durations and available resources.") }
}

@Composable
private fun ReadyScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=24.dp)) {
        item { GUHeader("Ready to run","Suggested schedule • ${if(s.timing==TimingMode.COOK_NOW) "Cook now" else "Target time set"}") { SettingsButton{dispatch("SETTINGS",null)} } }
        items(s.tasks.filter{it.status!=TaskStatus.DONE}) { t -> TaskRow(t) }
        item { Text("Suggestions are not guarantees. Reorder or override when reality changes.",color=MaterialTheme.colorScheme.onSurfaceVariant) }
        item { GUPrimary("Start board",{dispatch("BOARD_STARTED",null)},iconKey="play") }
    }
}

@Composable
private fun RunBoardScreen(s:KitchenUiState, paused:Boolean, dispatch:(String,String?)->Unit) {
    val rt=LocalGoodUse.current
    val now=s.tasks.filter{it.status==TaskStatus.ACTIVE}
    val next=s.tasks.filter{it.status==TaskStatus.AVAILABLE || it.status==TaskStatus.BLOCKED}
    val waiting=s.tasks.filter{it.status==TaskStatus.WAITING}
    val done=s.tasks.filter{it.status==TaskStatus.DONE || it.status==TaskStatus.SKIPPED}

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        GUHeader(s.boardTitle, if(paused) "Paused • timers continue" else "Board running") { SettingsButton{dispatch("SETTINGS",null)} }
        if(paused) {
            GUSection(emphasis=true) {
                GUStatus("Paused","warning")
                Text("Pausing the board does not pause or extend existing timer deadlines.")
                GUPrimary("Resume board",{dispatch("RESUME",null)},iconKey="resume")
            }
        }
        if(rt.wideBoard) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(16.dp),verticalAlignment=Alignment.Top) {
                Lane("Now",now,Modifier.weight(1.1f),active=true,dispatch=dispatch)
                Lane("Next",next,Modifier.weight(1f),dispatch=dispatch)
                Lane("Waiting",waiting,Modifier.weight(1f),waiting=true,dispatch=dispatch)
            }
        } else {
            Lane("Now",now,active=true,dispatch=dispatch)
            if(waiting.isNotEmpty()) Lane("Waiting",waiting,waiting=true,dispatch=dispatch)
            Lane("Next",next,dispatch=dispatch)
        }
        if(done.isNotEmpty()) Lane("Done",done,dispatch=dispatch)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            if(!paused) GUSecondary("Pause",{dispatch("PAUSE",null)},iconKey="pause",modifier=Modifier.weight(1f))
            GUSecondary("Finish",{dispatch("OPEN_FINISH",null)},modifier=Modifier.weight(1f))
        }
    }
}

@Composable
private fun Lane(title:String,tasks:List<PrepTask>,modifier:Modifier=Modifier,active:Boolean=false,waiting:Boolean=false,dispatch:(String,String?)->Unit) {
    GUSection(title,modifier=modifier,emphasis=active) {
        if(tasks.isEmpty()) Text("Nothing here",color=MaterialTheme.colorScheme.onSurfaceVariant)
        tasks.forEach { t ->
            Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(t.text,fontWeight=FontWeight.SemiBold)
                        t.detail?.let { Text(it,color=MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    t.minutes?.let { Text("${it}m",fontWeight=FontWeight.SemiBold) }
                }
                if(active) {
                    if(t.attention) GUStatus("Attention required","warning")
                    GUPrimary("Complete",{ },iconKey="complete")
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        listOf("+1","+2","+5").forEach { GUTextAction(it,{}) }
                        GUTextAction("Still cooking",{ })
                    }
                } else if(waiting) {
                    GUStatus("Timer running")
                    GUSecondary("Complete",{ },iconKey="complete")
                } else if(t.status==TaskStatus.AVAILABLE) {
                    GUSecondary("Do next instead",{ })
                } else if(t.status==TaskStatus.BLOCKED) {
                    GUStatus("Blocked")
                }
                HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.5f))
            }
        }
    }
}

@Composable private fun TaskRow(t:PrepTask) {
    GUSection {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(t.text,fontWeight=FontWeight.SemiBold); t.detail?.let{Text(it,color=MaterialTheme.colorScheme.onSurfaceVariant)} }
            t.minutes?.let{Text("${it} min",fontWeight=FontWeight.Medium)}
        }
    }
}

@Composable
private fun FinishScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    val unfinished=s.tasks.count{it.status!=TaskStatus.DONE && it.status!=TaskStatus.SKIPPED}
    Column(Modifier.padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        GUHeader("Finish board","$unfinished tasks are unfinished.")
        GUSection {
            Text("Finish anyway archives the board as incomplete. It does not mark remaining tasks done.")
        }
        GUPrimary("Continue board",{ if(s.paused) dispatch("RESUME",null) else dispatch("BOARD_STARTED",null) })
        GUSecondary("Finish anyway",{dispatch("FINISH_ANYWAY",null)})
    }
}

@Composable
private fun ReuseScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    Column(Modifier.padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        GUHeader("Board saved","Reuse the structure without carrying live task state or timers.")
        GUSecondary("Save as template",{ },iconKey="save")
        GUSecondary("Add note",{ })
        GUPrimary("Return home",{dispatch("RETURN_HOME",null)})
    }
}

@Composable
private fun SettingsScreen(s:KitchenUiState, dispatch:(String,String?)->Unit) {
    val groups=listOf(
        "Preferences" to listOf("Language","Locale","Units","Temperature"),
        "Privacy & data" to listOf("Privacy choices","Export local data","Import local data","Delete local data"),
        "Help" to listOf("Help","Privacy policy","Terms","Support"),
        "Subscription" to listOf("Remove ads — $1.49/month base price")
    )
    LazyColumn(verticalArrangement=Arrangement.spacedBy(16.dp),contentPadding=PaddingValues(bottom=24.dp)) {
        item { GUHeader("Settings","Local-first controls and support.") }
        groups.forEach { (title,rows) ->
            item {
                Text(title,style=MaterialTheme.typography.titleLarge)
                GUSection {
                    rows.forEachIndexed { i,row ->
                        ActionRow(row, if(row.startsWith("Remove ads")) "Google Play subscription • removes ads only" else "") {}
                        if(i<rows.lastIndex) HorizontalDivider()
                    }
                }
            }
        }
        item { GUPrimary("Done",{dispatch("CLOSE_SETTINGS",null)}) }
    }
}
